Guessing(JS)
